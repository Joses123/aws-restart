#print("hello world")
#print("Python has three numeric types: int, float, and complex")
#myValue=1
#print(myValue)
#print(str(myValue) + " is of the data type " + str(type(myValue)))

#firstString = "water"
#secondString = "fall"
#thirdString = firstString + secondString
#print(thirdString)

#name = input("What is your name? ")
#color = input("What is your favorite color?  ")
#animal = input("What is your favorite animal?  ")
#print("{}, you like a {} {}!".format(name,color,animal))

myFruitList = ["apple", "banana", "cherry"]
print(myFruitList)
print(type(myFruitList))
print(myFruitList[2])
print(myFruitList[1])

myFinalAnswerTuple = ("apple", "banana", "pineapple")
print(myFinalAnswerTuple)
print(type(myFinalAnswerTuple))

myFavoriteFruitDictionary = {
  "Akua" : "apple",
  "Saanvi" : "banana",
  "Paulo" : "pineapple"
}
print(myFavoriteFruitDictionary)