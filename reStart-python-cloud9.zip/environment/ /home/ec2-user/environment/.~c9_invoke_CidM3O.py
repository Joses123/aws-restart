print("hello world")
print("Python has three numeric types: int, float, and complex")